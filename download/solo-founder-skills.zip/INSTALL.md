# Installing

These are plain Markdown files. There's nothing to run and nothing to trust —
open any of them and read it first if you like.

## Claude Code (terminal or desktop app)

Put the skill folders where Claude Code looks for them:

**Just for one project:**
```
your-project/
└── .claude/
    └── skills/
        ├── idea-kill-search/SKILL.md
        └── ...
```

**For everything you do:**
```
~/.claude/skills/
├── idea-kill-search/SKILL.md
└── ...
```

Copy them in:
```bash
mkdir -p ~/.claude/skills
cp -r skills/* ~/.claude/skills/
```

Claude picks them up on the next session. It decides when to use each one based
on the description at the top of the file, so you don't need to name them — but
you can, by saying "use the idea-kill-search skill".

## Claude desktop or web app

Two options:

**As a skill** — if your account has skills enabled, upload the `SKILL.md` file
and it'll appear in your list.

**As project instructions** — make a project, open its instructions, and paste
in the contents of whichever skill fits. Simplest route if skills aren't enabled
for you.

## Other AI tools

They're Markdown, so they work anywhere that takes a system prompt or custom
instructions — paste the body of the file in. You'll lose automatic triggering
(that comes from the description), so just say which one you want.

## Using them

Most of the time you don't do anything. Describe your task and the right skill
triggers on its own.

Worth naming it explicitly when:
- You want a specific approach and Claude picked a different one
- You're starting something where you know the skill applies
- You want to compare with and without

```
Use idea-kill-search on this: a subscription box for office plants.
```

## Making them better

These improve when you put your own details in. Three good first edits:

1. **Add your stack.** In the deploy and hosting skills, replace the example
   commands with the ones you actually run.
2. **Add your numbers.** In `channel-benchmarking`, write in your real cost per
   result. It turns a method into your benchmark.
3. **Add your market.** In `idea-kill-search` and `store-listing-conversion`,
   note the regulators, platforms and stores that apply to you.

And when Claude does something wrong while following one, say "update that skill
so it doesn't do that again". It'll edit the file. That's how these were built.
