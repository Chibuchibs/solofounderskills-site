---
name: simulate-the-instructions
description: Check that whatever the on-screen instructions tell a user to do actually works, by simulating that exact strategy and seeing if it wins. Use this whenever someone says a game, quiz, form, tutorial, onboarding flow or interactive feature is "too hard", "impossible", "confusing", "frustrating" or "nobody completes it" — and before shipping anything with a timing element, a target to hit, a scored outcome, or a sentence telling the user what to do. Also use when tuning difficulty, balancing scoring, or reviewing a mini-game.
---

# Do the instructions actually work?

When someone says an interactive thing is too hard, the instinct is to make it
easier. Don't start there. First check whether doing exactly what the screen says
actually produces a good result.

Surprisingly often it doesn't — and then no amount of tuning helps, because the
difficulty was never the problem.

## The test

1. Read the instruction on screen. Write down, precisely, the strategy it
   describes.
2. Copy the underlying logic into a small standalone script — the physics, the
   scoring, the timing, whatever decides the outcome.
3. Run that strategy a few hundred times.
4. Compare it against two baselines: **the opposite strategy**, and **doing
   nothing at all**.

That third baseline is the one that catches the worst bugs. If following the
instructions scores the same as not playing, the instruction is wrong.

## What it looks like when it's broken

A real one. A balance game said:

> "Tap the side you are falling towards."

The code pushed the player **in the direction they tapped**. So the instruction
told people to speed up their own fall. Simulated over 300 runs:

| Strategy | Average falls |
|---|---|
| Tap the opposite side | **0** |
| Tap towards it (what the screen said) | **1,108** |
| Don't touch anything | **1,108** |

Following the instructions was worth exactly as much as not playing. Nobody could
have beaten it. The fix was one line of text, not a difficulty change.

## Three failures worth looking for

**The instruction is backwards.** Check which way the input actually pushes
things. Easy to get wrong when "lean left" could mean "I am leaning left" or
"push me left". Read the input handler, don't trust the variable names.

**The stated goal is unreachable.** If a counter says "3 of 5", players read 5 as
the goal. Work out the actual odds of getting there. One press-your-luck game
framed 5 as the target when 5 happened **0.17%** of the time — and every possible
strategy had a bad expected result, so there was no good way to play at all.

**The target is invisible.** Covered in the `target-legibility-audit` skill. If
the thing you're aiming at isn't drawn, or is drawn in a near-background colour,
people are guessing. That reads as "impossible" even when the maths is generous.

## Work out the window, not just the odds

"Fair" and "playable" aren't the same. For anything timing-based, convert the
margin into **milliseconds of reaction time**:

```
window_ms = cycle_duration_ms × (target_width_as_fraction) / 2
```

Divide by 2 because a sweeping marker crosses the target twice per cycle.

Under about 150ms is very tight for a phone. Compare games against each other —
in one case the basketball shot gave 88ms while the marching game gave 288ms, and
the basketball one was the one everybody called impossible. Same codebase, same
players, three times tighter.

## Checking the odds curve

For press-your-luck or risk/reward mechanics, don't just check whether the top
prize is reachable. Work out the expected score for **stopping at each point**:

```
stop at 1  avg 0.18
stop at 2  avg 0.30
stop at 3  avg 0.34   <- a real peak, so the decision matters
stop at 4  avg 0.30
stop at 5  avg 0.22
```

A clear peak in the middle means the player has a genuine choice. If the best
option is always "stop immediately" or "the numbers are bad everywhere", the
mechanic isn't a gamble, it's a tax.

## Proving the fix

Don't just ship it. Have the page play itself:

- For a visible target, read the pixel colour where the target is drawn and act
  when it changes.
- Aim for the **middle** of the target, not the first frame it's touched. First
  touch lands on the edge and under-reports — one bot scored 2/5 on edges and 5/5
  aiming at the centre, with no change to the game in between.
- If a bot that does what the screen says now scores well, the instructions and
  the mechanic agree.

## The habit worth keeping

When someone reports that something is too hard, ask first: *did they know what
to do?* Three separate "this is impossible" reports on one project all turned out
to be instructions nobody had read or that were plain wrong. Not one was a
difficulty problem.
