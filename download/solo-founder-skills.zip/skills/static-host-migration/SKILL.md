---
name: static-host-migration
description: Move a static site to a new host without breaking email, with minimal DNS changes and a working certificate. Use this whenever someone is changing web hosts, hitting deploy limits or build-credit caps, considering a move to GitHub Pages, Netlify, Vercel or Cloudflare Pages, or asks about DNS records, nameservers, A records, CNAMEs, or an SSL certificate that won't provision.
---

# Move the site, don't break the mail

The real risk in a host migration isn't the website. It's email. Mail lives in
the same DNS zone, and the usual migration advice will happily tell you to move
the whole zone.

## Check first: has it already been moved?

If several sites share an account, one may already have migrated for exactly the
reason you're now hitting. Check before planning anything.

Also worth knowing: some hosts meter **production deploys**, not bandwidth. A
free plan with 300 credits a month at 15 credits a deploy is 20 deploys a month —
shared across every site in the account. One project iterating hard can spend the
whole allowance and strand the others until the reset.

## The rule that protects your email

**Prefer a host that lets you change only A records and a CNAME.**

- Hosts publishing **fixed apex IPs** need only those records changed. MX, SPF,
  DKIM, DMARC and all the service CNAMEs stay untouched. Low risk.
- Hosts requiring you to **move the nameservers** move the entire zone, mail
  records included. If there's business email on that domain, the blast radius is
  everything.

A real case: a domain with hosted business email had autodiscover, lyncdiscover,
msoid CNAMEs, SIP SRV records, an SPF include and the MX. Moving nameservers
would have put all of it at risk for a website change. Changing four A records
and one CNAME did the same job and never touched mail.

That's not a reason to avoid nameserver-based hosts forever — it's a reason not
to take that risk for a routine hosting change.

## Before you touch anything

Snapshot the zone so you can prove what changed:

```bash
for t in A AAAA CNAME MX TXT NS SRV; do
  echo "--- $t"; dig +short "$t" example.com
done > dns-baseline-$(date +%F).txt
dig +short TXT _dmarc.example.com
dig +short CNAME www.example.com
```

Keep that file. When something looks wrong three days later, it's the only way to
know whether you caused it.

## Keep the source separate from what you publish

Publish a **build output**, not your working folder. One site served its database
migration files publicly because the publish directory was set to `.` — which
exposed a blocked-word list and the exact spam-filter patterns.

Copy an explicit allowlist of files into a `dist/` folder and publish that. If a
file isn't named in the build script, it can't leak.

## When the certificate won't provision

Certificate state stuck at pending for a long stretch is common and usually
fixable immediately rather than by waiting.

The trick that works: **unclaim the custom domain, then claim it again.** On
GitHub Pages that's a `PATCH`/`PUT` to the pages API with an empty `cname`, then
the same call with the domain. A certificate that had been stuck for over an hour
was approved in about a minute. Then enforce HTTPS.

Don't sit waiting on it for hours first — try the re-claim early.

## TTL and timing

- Lower TTLs **before** the change if you can, so mistakes are cheap to undo.
- Some registrars take TTL in **seconds with a minimum** — typing "10" meaning
  ten minutes gets rejected. Read the unit.

## Verify after cutover

```bash
for p in / /about /pricing; do
  curl -s -o /dev/null -w "$p %{http_code}\n" "https://example.com$p"; done
curl -s -o /dev/null -w 'http  -> %{http_code} %{redirect_url}\n' http://example.com
curl -s -o /dev/null -w 'www   -> %{http_code} %{redirect_url}\n' https://www.example.com
echo | openssl s_client -connect example.com:443 2>/dev/null | openssl x509 -noout -subject -dates
dig +short MX example.com        # must match the baseline
dig +short TXT example.com       # SPF must match the baseline
```

**Send yourself an email** both ways after the change. DNS looking right isn't
the same as mail flowing.
