---
name: target-legibility-audit
description: Find the UI elements people can't see — targets, safe zones, active states and the thing they're meant to aim at. Use this whenever someone says an interface is confusing, hard, "impossible", or that they "missed" something on screen, and whenever reviewing a game, chart, form, dashboard or any screen where one element moves against another. Also use before shipping any canvas or custom-drawn UI, and when picking colours for a thing a user has to hit, read or react to.
---

# Can they actually see it?

A lot of "this is too hard" is really "I couldn't see what I was supposed to aim
at". Cheap to check, cheap to fix, and easy to miss because you already know
where everything is.

## The rule

**The target should be more visible than the thing that moves.**

It's natural to spend the strong colour on the moving part, because that's the
part that feels alive. But the moving part draws the eye by moving. The target is
static, so it needs the contrast.

Getting this backwards is common. One real case: the target band was pale mint on
light grey, while the marker sweeping across it was strong green. The thing you
aimed at was the hardest thing on screen to see, and the thing you didn't need to
look for was the easiest. Players called the game impossible. Nothing was wrong
with the mechanic.

## What to check

Go through every screen where someone has to hit, read or react to something:

- **Is the target drawn at all?** Sometimes there just isn't one — the player is
  guessing where the good zone is. Drawing it is the whole fix.
- **Does the target contrast with its own background?** Not with the page, with
  whatever it sits directly on top of.
- **Does the marker contrast with the target?** A green marker over a green band
  disappears exactly when it matters. Use different hues, not different shades —
  orange on green works, light green on dark green doesn't.
- **Is there an active state?** When the marker is on target, something should
  change. Brighten the band, add a word, change the colour.
- **Does it survive daylight?** Pale-on-pale looks fine on a desktop monitor in a
  dark room and vanishes on a phone outdoors. That's where most of your users are.

## Practical colour pairs

What worked, after the pale version failed:

| Part | Colour | Why |
|---|---|---|
| Track / background | Warm light grey | Neutral, so both the others stand out |
| Target zone | Solid mid-green, darker border | Reads as "here" at a glance |
| Target when active | Brighter green + a word like "NOW" | Confirms the moment |
| Marker | Orange, with a pointer | Different hue, never camouflages |
| Danger zones | Dark red at the extremes | Obvious without reading anything |

## Sweeping for it

If one near-invisible colour slipped in, others probably did too. Grep for the
specific hex value across the codebase — in one case the same pale mint was used
as the target in two different games, both reported as impossible, months apart.

Also check where instructions sit. Small grey text **below** a canvas is past the
fold on a phone, and for anything timed you need it before you act, not after.
Move the instruction above the thing it describes and give it real contrast.

## Don't fix the wrong thing

Before changing any difficulty numbers, check legibility first. Every time a
"too hard" complaint turned out to be a contrast or instruction problem, tuning
the difficulty would have made the game worse — easier *and* still unreadable.
