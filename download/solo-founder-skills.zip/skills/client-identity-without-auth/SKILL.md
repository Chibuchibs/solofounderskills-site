---
name: client-identity-without-auth
description: Let people use a multiplayer or shared app with no signup, while keeping the database safe from anyone who opens the console. Use this whenever someone is building something with shared state — a leaderboard, chat, presence, comments, a collaborative page — and wants to avoid a login wall, or asks about row-level security, anonymous keys, Supabase, Firebase rules, or "can people cheat this?".
---

# No signup, still safe

A login wall at the front door costs you most of your visitors. You can skip it
and still keep the database honest — but only if the client is treated as
hostile, because it is. Anything shipped to the browser is readable, and any
endpoint the browser can call, anyone can call.

## The shape that works

**1. No write policies at all.**

Turn on row-level security and grant the public key **read access only, where
reading is genuinely public**. No insert, no update, no delete. Ever.

**2. Every write goes through a function that runs with elevated rights.**

The function validates, clamps and decides. The client can only ask; the server
decides what actually happens.

```sql
create or replace function do_the_thing(p_token uuid, p_value text)
returns boolean language plpgsql security definer set search_path = public as $$
declare clean text; pid uuid;
begin
  select id into pid from players where token = p_token and not banned;
  if pid is null then return false; end if;

  clean := left(nullif(trim(p_value), ''), 16);
  if clean is null or char_length(clean) < 2 then return false; end if;

  update players set value = clean where id = pid;
  return true;
end $$;

grant execute on function do_the_thing(uuid, text) to anon, authenticated;
```

Note what it does: looks the caller up by token, refuses banned users, trims and
length-caps the input, and returns a boolean rather than leaking why it failed.

**3. Identity is a random token in local storage.**

Generated server-side on first write, stored in the browser, sent with every
call. It isn't authentication — it's a handle. Good enough for "this is the same
person as yesterday", not good enough to protect anything valuable.

Because it's weak by design, never let it unlock anything that matters. It's an
identifier, not a password.

## The rules that keep it safe

- **Never ship the service key.** Only the publishable/anon key belongs in client
  code. The service key bypasses every policy you just wrote.
- **Never put the token in anything broadcast.** Presence payloads are readable
  by every connected client. Send nickname, not token.
- **Ban by id, never by name.** Names change; ids don't. Banning by name bans the
  next person to use it.
- **Clamp server-side.** Any value from the client is a suggestion. Trim, cap
  length, bound numbers, scrub anything from a URL to plain characters.
- **Know your kill switch.** Write it down before launch. For public chat it's
  one line that revokes read access. You want it ready at 2am, not researched.

## Create the row when it means something

Don't create a user row on page load. Create it on the **first real action**.

This keeps "users" meaning "people who did something" rather than "people who
loaded the page", which is the number you actually want. Worth knowing: it also
makes your count non-comparable to anything from before the change, so expect the
raw number to look worse while the funnel is genuinely better. Say that out loud
when you report it.

## Letting people set a name later

If you skip signup, you need a way to set a name afterwards — the join-time
function isn't enough.

Add a rename function with the same validation shape, and have it **also update
any existing content** that carries the name, so one person doesn't appear under
two names in a history.

Then ask for a name only where it matters. Public, permanent surfaces — chat,
anything others will read — are worth gating. Private ones aren't. Gating
everything just rebuilds the signup wall you removed.

## Auto-assigned names

Give people a name on arrival so nothing is blocked. Two things to watch:

- **Respect the server's length cap** when generating it. If names are capped at
  16 characters and your prefix is 13, you have 3 characters for digits — four
  would be silently truncated and you'd have collisions you can't see.
- **Don't make it too good.** A name that sounds real means nobody ever sets
  their own, which costs you exactly what the name was for. It should read as a
  placeholder.
- **Match old formats too.** When you change the generated format, keep
  recognising the old one, or existing users stop being prompted.
