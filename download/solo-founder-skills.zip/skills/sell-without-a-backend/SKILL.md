---
name: sell-without-a-backend
description: Take real money for a digital product using a payment link, a static thank-you page and a file — no server, no database, no login. Use this whenever someone wants to sell a download, a template, an ebook, a course file or any digital product, asks how to take payments without building a backend, is choosing between payment platforms or marketplaces, or is about to publish a buy button. Also use before the first real sale, because the ways this breaks are silent and the buyer finds them first.
---

# Sell a file without building anything

The whole chain can be four things you already have: a payment link, a redirect,
a static page, and a zip. No server, no accounts, no database.

What follows is the order to build it, and the failures that are invisible until
a stranger hits them.

## The chain

1. **A payment link** from a payment provider — a hosted checkout page you don't
   build or maintain
2. **A redirect after payment** to a page on your own site
3. **A thank-you page** holding the download link and the first instructions
4. **The file itself**, served as a static file

Every step is a thing that can silently not work. Test all four with real money
before anyone else does.

## Test it by buying it

Pay for your own product with a real card, then refund yourself. Not a test-mode
transaction — a real one, through the real button on the real page.

Walk the path a stranger walks:

- Click the button **on your site**, not the payment link directly
- Does the redirect fire, or do you land on the provider's generic receipt?
- Does the file download, and does it open?
- Does the receipt email arrive, and does it say your product's name?
- What does the charge look like on the statement?

Expect to lose a small amount. Providers usually keep the original processing
fee on a refund, so a test costs roughly what the fee was. That is the cheapest
information you will buy all year.

## ⚠️ A 200 response does not mean the page works

The single most dangerous check in this whole process.

Hosted checkout pages are usually a thin shell that loads the real content
afterwards. Request a **payment link that does not exist** and you still get a
successful response and a complete-looking page — which then renders "the page
you were looking for could not be found."

A real case: a dead checkout went live and the automated check reported success
the entire time, because the check looked at the status code.

📌 **Load the page and read the text.** A status code tells you a server
answered, not that a customer can buy.

## ⚠️ Never retype an identifier you read off a screen

Payment link IDs are long random strings. In almost every interface font,
capital `O` and zero are indistinguishable, as are `1`, lowercase `l` and
capital `I`.

A real case: a capital `O` was read as a zero. The site shipped a checkout that
went nowhere, and the status-code check above reported it as healthy.

Copy it from the provider's copy button and paste it. Never transcribe it by
eye, including from a screenshot you took yourself.

## What your charge looks like on a statement

The line a buyer sees on their bank statement is a common cause of chargebacks:
an unfamiliar string two weeks later gets disputed, and a dispute costs you the
sale plus a fee, and counts against your account.

Set the **statement descriptor** to something they will recognise — your product
name or, better, your domain, which they can type into a browser. Check what it
actually renders as; some providers prepend their own name and truncate yours.

## Refund policy: the thing it has to include

Whatever you choose, a policy of "no refunds" does **not** stop chargebacks. It
redirects them. A buyer who can't get a refund goes to their card issuer, which
costs you the money *plus* a dispute fee, and a poor dispute ratio can close a
young account.

So a no-refund policy needs a valve:

> If something is wrong — the download fails, the file won't open — email me and
> I'll fix it.

That promises to fix broken files, not to refund. It costs nothing and gives an
annoyed buyer somewhere to go that isn't their bank.

Two more points worth stating plainly rather than hiding:

- If your payment provider acts as merchant of record, **they can refund under
  their own rules** regardless of your page. Write the policy as yours, not as
  an absolute.
- Some countries give buyers a statutory cancellation right on digital goods
  that your terms cannot remove. Acknowledging it reads as more credible than
  pretending otherwise.

📌 **Free samples are a stronger substitute for a guarantee.** Giving away one
or two complete pieces of the product lets a buyer verify quality themselves
instead of trusting you to honour something later. It also makes "all sales
final" read as fair rather than defensive.

## The delivery page is guessable

A static thank-you page has no gate. Anyone who guesses the URL can download the
product.

That is an acceptable trade for a low-priced item — the alternative is the
backend you were avoiding — but know it, so you're not confused later when
downloads outrun sales. If the gap gets wide, that's the signal to add real
gating, not a surprise.

## Rebuild the file automatically or it will go stale

If the file you sell is assembled by hand, every later edit to the source leaves
buyers downloading an old version. This is silent: nothing errors, and you only
discover it when someone quotes the product back at you from an earlier draft.

A real case: a product assembled once by hand went stale after days of edits.
Nobody noticed until the file was opened on purpose.

**Put the packaging step inside the deploy script**, so publishing the site and
rebuilding the file are the same action and cannot drift apart.

## Compare channels on what you keep, not the headline rate

Fees are quoted in ways that are hard to compare. Work out the actual number for
one sale at your price:

| Channel | What's taken | You keep on a $49 sale |
|---|---|---|
| Your own site, direct | ~7% all in | ~$45.50 |
| Marketplace, your own traffic | 10% + 50¢ **plus** 2.9% + 30¢ | ~$41.90 |
| Marketplace, their traffic | 30% inclusive | ~$34.30 |

Two things fall out of that:

- A buyer who arrives through a marketplace's own browsing costs you roughly
  a quarter of the sale. That is not a fee, it's a **customer acquisition cost**,
  and it's worth paying for someone who would never have found you.
- A buyer you could have sent to your own site costs you the same quarter for
  nothing. Keep your price identical everywhere, so you never train people to
  buy through the expensive door.

⚠️ **Marketplace discovery is often gated.** At least one major platform
requires completed payouts, a minimum balance from genuine sales, a risk review
and a prior non-refunded sale before your product appears in its browsing at
all — and the category field doesn't even appear until you qualify. Check the
gate before you choose a platform for its traffic, or you'll get the fees
without the discovery.

## Before you send anyone to it

- Bought it yourself with a real card and refunded
- Redirect lands on your page, not the provider's
- File downloads and opens, and is the current version
- Receipt names your product
- Statement descriptor is recognisable
- Terms published, with a route to email you
- A support address that actually receives mail

The last one is not optional. A published support address that bounces turns a
fixable complaint into a chargeback.
