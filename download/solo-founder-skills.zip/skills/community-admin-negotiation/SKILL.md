---
name: community-admin-negotiation
description: Judge what a community group, forum or page is actually worth to advertise in, and negotiate with its admin without overpaying or getting banned. Use this whenever someone is considering paying for a promoted post, sponsored mention or shoutout in a Facebook group, Discord, subreddit, forum, newsletter or WhatsApp community, when an admin quotes them a rate, when they ask "is this group worth it?", or when they're about to post their own link into someone else's community.
---

# What is that group actually worth?

Member count is the number admins quote and the one that means least. Here's what
to work out instead, all of it visible without logging in.

## Read the group before you talk to anyone

Most group pages publish an activity section. Pull out:

- **Members**
- **Posts today** and **posts last month**
- **When it was created**
- **Who the admins are** (confirms the person messaging you can deliver)

Then work out the two numbers that matter.

**Posting rate per member** tells you if it's a community or a dumping ground:

```
posts per day ÷ (members / 1000)
```

**How long your post survives** before it's buried:

```
burial_minutes ≈ (16 × 60) / posts_per_day
```

(16 hours is a rough active day.)

## What that looks like in practice

Real comparison across six groups:

| Group | Members | Posts/day | Buried after |
|---|---|---|---|
| A | 753,000 | 130 | ~7 min |
| B | 801,000 | 54 | ~18 min |
| C | 130,000 | 12 | ~80 min |
| D | 72,000 | 24 | ~40 min |
| E | 50,000 | 7 | ~2.3 hrs |
| **F** | **21,000** | **117** | **~8 min** |

Group F was asking the highest price. It's the smallest group with nearly the
shortest post life — it posts at **17 to 84 times** the rate per member of every
other group on the list. That's not a lively community, it's a spam feed, and one
post in it disappears in minutes.

Without the table, F looked like a reasonable deal.

## Beware the stat that appears everywhere

One group showed "no new members in the last week" and it looked like a red flag
— until the same line appeared on **all six**, including one with 800,000
members. Six groups don't flatline at once. It was a reporting quirk.

If you're about to use a number as a negotiating point, check whether it appears
on every group you've looked at. If it does, it's telling you nothing.

## Read the rules before you post anything

Most of these groups explicitly ban promotion: *"self-promotion, spam and
irrelevant links aren't allowed."*

Two things follow:

1. **Posting your link yourself gets you suspended.** That's not bad luck, it's
   the stated rule. The real risk isn't the suspension — it's the platform
   flagging **your domain**, which kills your link in every group and in private
   messages at once, and is much harder to undo.
2. **An admin-placed post is worth more than it looks**, because they're selling
   you an exemption from their own rule. That's the thing you can't get any other
   way.

## What to ask for

Three things, every time:

- **Reach per post for the last 30 days.** This is the number that decides
  everything, and the one most likely to be dodged. Any admin can pull it in two
  taps. If they won't show it, that's your answer and it cost you nothing.
- **A pinned or featured post**, not a normal one. Free for them to grant, and in
  a busy feed it's the difference between hours of visibility and eight minutes.
  This is the highest-value ask and it's easy to forget.
- **A tracking link.** Without it you'll be exactly where you started.

## How to structure the offer

- **Test small, then scale.** One cheap tracked post, then commit to more if it
  performs. Say that openly — it reads as professional, not distrustful.
- **Half up front, half on posting.** Normal for a first job between strangers.
- **Offer something that costs you nothing.** A permanent mention inside your own
  product, free, regardless of how the numbers go. It makes the whole thing read
  as a partnership instead of a haggle, and it's often what gets a reply.
- **Don't name competitors.** You'll know the market after two quotes. They don't
  need to know you're shopping.

## Timing is leverage

If your audience is seasonal — a cohort, an intake, an event — a post outside
that window is worth much less to you, and the admin usually hasn't thought about
it. Saying so honestly is both true and useful: *"this week has four days of
life for me; that other window is worth far more, and I'll book two posts there
if this one performs."*

Also judge a test post run in a bad window on **clicks, not retention**. A flop
in the wrong week can't tell you whether the group is good.

## Don't send the same message four times

Identical messages to several admins is the pattern spam detection looks for,
and it's especially risky if you've already been suspended somewhere. Space them
out, change the opening line, and reference something specific about each group.
