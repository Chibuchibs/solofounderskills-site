---
name: agent-inbox-triage
description: Connect an AI assistant to a support inbox so it reads incoming mail, works out what each message is really about, and writes replies for you to approve — without ever sending on its own. Use this whenever someone wants AI to handle, triage, summarise or answer their email or support requests, mentions connecting an assistant to Gmail or an inbox, asks about automating customer support, or is drowning in support mail they answer by hand. Also use before giving any AI tool access to a mailbox, because the account you connect it to is the decision that matters most.
---

# Let an assistant read your support mail

The appeal is obvious: support mail is repetitive, and an assistant that reads
it and writes the reply saves real time. What almost every guide to this skips
is that the risky part isn't the drafting. It's **which inbox you point it at**,
and **whether it can send**.

Get those two wrong and the first thing you'll know about it is a customer
replying to something you never read.

## Do this first: a dedicated inbox

**Do not connect an assistant to the inbox you live in.**

Support mail usually forwards into a personal address, because that's the
easiest way to set it up. If you then connect an assistant to that account, it
can read everything you receive — bank mail, family, the lot — not just the
support messages you meant to share.

The fix is a separate, free mailbox that holds nothing else:

1. Create a new mail account that exists only for support
2. Point your support address at it (if you use forwarding, change the
   destination; don't add a second one — a copy going to your personal inbox
   means you read both and the separation stops meaning anything)
3. Connect the assistant to the new account only
4. Send a test and confirm it lands in the new inbox **and not** the old one

Measured on a real setup: the dedicated inbox contained four messages, all
support-related. Nothing personal was reachable. That is the entire benefit, and
it costs ten minutes.

📌 **Set the account's display name to your business name before it sends
anything.** New mail accounts default to whatever name you signed up with —
often your own. That name appears on every reply a customer receives.

## The permission you cannot grant

When you authorise an assistant, you'll pick what it can access. You will want
"read and draft, but not send."

**That option does not exist.** At least on Gmail, drafting and sending are a
single permission — the consent screen says "Manage drafts **and send**
emails." Tick it and the assistant *can* send. There is no scope that allows one
without the other.

So "never send" is **a rule you give the assistant, not a setting you configure.**
Put it in the instruction every time:

```
Read the unread support mail. For each one, tell me what it's about and draft a
reply. Do not send anything — drafts only.
```

Anyone who tells you to "just let it draft" has not read the consent screen.

⚠️ Grant the narrowest scopes that work: viewing messages, and managing drafts.
Decline broader "read, compose and send" style scopes stacked on top — they add
reach you don't need.

## Make it check before it apologises

The default behaviour of an assistant handed a complaint is to accept the
customer's diagnosis and apologise for it. That produces replies that are polite
and wrong.

A real case. The message said:

> Bought the pack this morning but the file won't open on my laptop. Windows
> says the archive is invalid. Can you resend it?

The obvious draft is "sorry, here's a fresh copy." Instead, the file was tested
first — both the stored copy and a fresh download from the live link. Both were
intact, and no filename in it would upset Windows.

So the product wasn't broken. A half-finished download reports as "invalid",
and Windows separately blocks archives from the web and *also* reports that as
corruption. The reply could then say something true and useful — download it
again and let it finish; if it still refuses, right-click, Properties, Unblock —
instead of apologising for a fault that didn't exist.

**Tell it to verify the claim before writing the reply:**

```
Before drafting, check whether the problem is real: test the file, the link, or
the account they're describing. Say what you found.
```

This is the difference between an assistant that answers mail and one that
handles support. It also stops you shipping "fixes" for things that work.

## Reviewing what it wrote

**Drafts don't always appear in the conversation.** A draft created through a
connector may not show in the thread view, only in the Drafts folder. People
assume it failed, ask again, and end up with duplicates. Check Drafts before
retrying.

⚠️ **If you're signed into more than one account, you will be shown the wrong
one.** This happened during a real run: opening Drafts to review one support
reply showed **27 drafts from a personal account** instead — photos, a bank
statement, old half-written messages. The support account had exactly one draft.

Two defences, use at least one:

- Open mail with an explicit account in the URL rather than clicking through
- Keep the support account in a different browser profile entirely

This matters more than it looks. The same wrong-account click at the
authorisation screen is how people hand an assistant their personal inbox while
believing they shared a support one.

## Don't trust the connector's own error messages

After a crash, the connector showed:

> Authorization with this connector failed. You can check your credentials and
> permissions.

It hadn't. The message was stale. The connector read the inbox correctly on the
very next request. Reconnecting on the strength of that banner means a wasted
re-authorisation and a second security alert to your users.

**Test it instead.** Ask it to list the last few messages. If they come back, the
connection is fine whatever the banner says.

## If you're not on Gmail

The same shape works through IMAP, which every mail provider supports. The cost
is setup: you must turn on two-factor authentication, generate an **app
password** — a separate 16-character password that works only for mail, can be
revoked on its own, and can't log into the rest of the account — then paste it
into whatever reads the mailbox.

Worth knowing: an app password still grants **full access to that mailbox**.
It limits which *service* is exposed, not what the holder can do with your mail.
Revoke it when you stop using it.

Prefer the connector route if your provider offers one. It's a few clicks and an
approval screen, with no credential for you to store or leak.

## What good looks like

- A mailbox that holds support mail and nothing else
- An assistant that reads it, says what each message is about, and drafts
- You approving before anything leaves
- A verification step before any apology
- A display name that says your business, not your own name

The time saved is real. The failure mode — an assistant sending a confident,
wrong reply to a paying customer in your name — is also real, and it's entirely
prevented by never letting it send.
