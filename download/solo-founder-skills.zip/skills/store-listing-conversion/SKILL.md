---
name: store-listing-conversion
description: Treat every store-facing surface as a conversion lever — screenshots, subtitle, title, description — rather than a form to fill in. Use this whenever someone is preparing or updating an App Store, Play Store, Chrome Web Store, marketplace or product-page listing, writing a subtitle or description, choosing screenshots, or asks why their downloads or signups are low despite traffic.
---

# Every field is a lever, not a box to tick

Store listings get filled in like paperwork and then never touched. But the
listing is the entire conversation between "someone found you" and "someone
installed you", and most of it is decided in about three seconds.

## Where the work actually happens

**The first two screenshots and the subtitle.** That's what shows in search
results without anyone tapping through. Everything below the fold is for people
already interested — useful, but it isn't what converts.

So: if you have an hour, spend fifty minutes on the first two screenshots and
the subtitle, and ten on everything else.

## Screenshots

- **Lead with the outcome, not the interface.** A screenshot of your settings
  page tells nobody anything. Show the thing the product does for them.
- **Put a short caption on each.** Most people read the caption and not the
  screen behind it. One line, plain words, what they get.
- **The first one should work at thumbnail size.** Squint at it. If the message
  survives, it's good.
- **Re-shoot when the product changes.** Stale screenshots showing an old
  interface read as abandoned.

## Subtitle

One line, and it's doing search work as well as selling. Say what it does and for
whom. Avoid saying your own name — the name is already there.

## Description

The first two lines show before "more". Treat those as a second subtitle.
Everything after is for people who are already considering it.

## Things that quietly cost you

- **No social image on your website**, so every shared link renders blank.
- **A review rejection on a technicality** — a missing required link, a missing
  disclosure — costs days. Check the required fields for your category before
  submitting, not after.
- **Price without regional thinking.** A price that's reasonable in one market
  can be a week's wages in another. If you sell internationally, check what your
  tiers convert to where your users actually are.
- **A listing that's live but never shared.** Being published isn't marketing. A
  product with a perfect listing and no traffic converts nothing.

## The honest check

Before you call a listing done, ask: if a stranger saw only the icon, the
subtitle and the first screenshot, would they understand what this is and who
it's for? If not, the rest doesn't matter.
