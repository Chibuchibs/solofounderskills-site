---
name: cohort-retention-analysis
description: Tell whether a product change actually improved retention, by comparing groups who joined before and after it instead of looking at a lifetime average. Use this whenever someone asks if a change worked, mentions retention, churn, drop-off, "people don't come back", average session length or daily actives, or is looking at usage numbers and trying to decide what to build next.
---

# Lifetime averages hide everything

A single average across everyone who ever used the product is dominated by
whoever is most numerous — usually people from before your change. It can sit
perfectly still while the thing you shipped is working.

Split by **when they arrived**, then compare the same milestone across groups.

## The query shape

```sql
select
  case when created_at < '<change date>' then 'before' else 'after' end as cohort,
  count(*)                                              as people,
  count(*) filter (where progress >= 5)                 as reached_5,
  round(100.0 * count(*) filter (where progress >= 5) / count(*), 1) as pct_5,
  count(*) filter (where progress >= 10)                as reached_10,
  round(100.0 * count(*) filter (where progress >= 10) / count(*), 1) as pct_10
from users
group by 1;
```

Pick milestones that mean something in your product — a day, a session, a level,
a completed step.

## Reading it honestly

A real result:

| | Before | After |
|---|---|---|
| Reached step 5 | 17% | 17% |
| Reached step 10 | **7.1%** | **17.6%** |

The front door didn't change — the same share got to step 5. But of those who
did, **100% carried on to step 10, against 42% before.** The change fixed the
middle of the product, not the entry.

That's a much more useful finding than "retention went up", because it tells you
where to work next: the entry is now the weak part.

## Say how confident you are

With small numbers, say so. With 17 people in the new group, a result like that
has roughly a one-in-nine chance of being luck. That's suggestive, not proven.

Two things that bias these comparisons, worth stating:

- **The newer group has had less time.** If they've had hours and the old group
  had weeks, the new numbers are biased *downward* — so an improvement is
  understated, which strengthens the finding.
- **A definition change breaks comparability entirely.** If you changed what
  counts as a "user" — say, from "loaded the page" to "did something" — then the
  two groups aren't measuring the same thing and no comparison is valid. Note the
  date and start a fresh baseline.

## What to do with it

- Milestone went up, entry flat → work on entry next
- Entry up, milestone flat → you're bringing in people the product doesn't hold
- Both flat → the change didn't do what you thought; don't build more of it
- Both up → say which you think did the work, and how you'd check

Report the number of people alongside every percentage. "17.6%" out of 17 people
is three people. Percentages without denominators invite bad decisions.
