---
name: seo-foundation-audit
description: Lay the technical SEO foundation for a site — canonical host, robots, sitemap, social cards, structured data — measuring what the server actually does instead of assuming. Use this whenever someone mentions SEO, search rankings, Google Search Console, "why isn't my site showing up", sharing links that look blank, canonical URLs, sitemaps, robots.txt, structured data or schema markup, and whenever a new site or landing page is about to go live.
---

# Technical SEO foundation

Before any content work, get the plumbing right. It's a couple of hours, it's
mostly checkable, and content built on a broken foundation wastes the effort.

## Step 1 — find out which host is really canonical

Don't assume www or apex. **Measure it**, because the answer differs per site and
getting it backwards poisons every canonical tag you write.

```bash
for u in "http://example.com" "https://example.com" \
         "http://www.example.com" "https://www.example.com"; do
  printf '%-32s -> %s\n' "$u" "$(curl -s -o /dev/null -w '%{http_code} %{redirect_url}' "$u")"
done
```

Whichever URL returns **200 without redirecting** is your canonical host.
Everything else should 301 to it.

Two sites in the same portfolio came out opposite ways — one apex-canonical, one
www-canonical. Copying the convention across would have broken one of them.

**The bug to look for:** `og:url` or `<link rel="canonical">` pointing at a URL
that *redirects*. It's easy to write the www form out of habit when the apex is
canonical. Check the tags resolve to the 200, not the 301.

## Step 2 — check for duplicate paths

On many static hosts, `/about` and `/about.html` both return 200. That's the same
page at two URLs, which splits your signals.

```bash
curl -s -o /dev/null -w '%{http_code}\n' https://example.com/about
curl -s -o /dev/null -w '%{http_code}\n' https://example.com/about.html
```

If both are 200, pick one, make it canonical everywhere, and disallow the other
in robots.txt.

## Step 3 — the foundation files

- **robots.txt** — allow the real pages, disallow the duplicate twins, point at
  the sitemap
- **sitemap.xml** — canonical URLs only, nothing that redirects
- **`<link rel="canonical">` on every page** — self-referencing, absolute,
  canonical host
- **Open Graph + Twitter card with a real image** — without `og:image` every
  share renders blank, which quietly costs you clicks on every link anyone posts
- **JSON-LD structured data** — Organization or WebSite on the home page,
  FAQPage where you genuinely have Q&A
- **Remove the obsolete `keywords` meta** if it's still there

## Step 4 — titles that match what people search

A brand-led home title (`BrandName`) wastes the most valuable string on the site.
Lead with what it does, then the brand.

## Step 5 — verify after deploying, not before

```bash
for p in / /about /pricing; do
  printf '%-14s %s\n' "$p" "$(curl -s -o /dev/null -w '%{http_code}' https://example.com$p)"
done
curl -s -o /dev/null -w 'robots  %{http_code}\n'  https://example.com/robots.txt
curl -s -o /dev/null -w 'sitemap %{http_code}\n'  https://example.com/sitemap.xml
curl -s -o /dev/null -w 'ogimage %{http_code}\n'  https://example.com/og-card.png
curl -s https://example.com/ | grep -o '<link rel="canonical"[^>]*>'
```

Confirm: every page 200, http → 301 → https, non-canonical host → 301 → canonical,
sitemap lists only 200s, JSON-LD present, social image loads.

## Things that bite

- **A Search Console verification tag already in the HTML** — don't delete it
  during a rewrite. Re-verifying is annoying and your history is attached to it.
- **Canonical pointing at a redirect** — the most common own-goal.
- **A sitemap listing redirecting URLs** — wasted crawl, mixed signals.
- **Blank social cards** — check with a card validator before announcing anything.

## What comes after

Foundation first, then Search Console verification, then content. Content pages
are usually blocked on having something real to say, not on effort — if the data
or the expertise isn't there yet, say so rather than filling pages with thin
text, which is actively penalised now.
