---
name: attribution-discipline
description: Tag links before posting so you can tell which channel actually worked, and understand what a big "direct" number is really hiding. Use this whenever someone is about to post, share or advertise a link anywhere — social, forums, groups, newsletters, bios, QR codes — and whenever they're looking at traffic or signup data and wondering where people came from, or say things like "I don't know if it's working" or "most of my traffic is direct".
---

# Tag it before you post it

The cheapest marketing mistake to avoid: posting a link with no tag, then having
no way to know whether it worked.

It's a minute of work beforehand and completely unrecoverable afterwards.

## How

Add a short tag to the link and record it on the way in:

```
yoursite.com/?r=tt     short video platform
yoursite.com/?r=fb     a social group
yoursite.com/?r=nl     a forum ad
```

Keep tags short, lowercase and boring. They're visible to anyone who looks at the
URL, so don't put anything in them you wouldn't want read.

On the server, scrub the value before storing it — it arrives from a URL anyone
can edit. Strip it to plain characters and a sensible length:

```sql
nullif(left(regexp_replace(coalesce(p_source,''), '[^a-zA-Z0-9_-]', '', 'g'), 24), '')
```

Store it once, on the row that represents a real result. Then a single query
answers the question everyone keeps guessing at.

## What a big "direct" number hides

"Direct" doesn't mean people typed your name from memory. It means **you failed
to tag something**, or the platform stripped it.

Real sequence worth learning from:

- A video was posted with an untagged link. It did ~700 views.
- Nothing attributable showed up, so the channel looked dead.
- A week later the link in the profile was tagged.
- Within hours, tagged results started appearing from the same old post.

Those views had been converting the whole time, landing silently inside "direct".
That share can never be recovered — the people are counted, just not attributed.

So: **a big direct bucket is a measurement failure, not a mystery.** Before
concluding a channel didn't work, check whether it was ever tagged.

## Platform gotchas

- **Captions usually aren't clickable** on short-video platforms. The only
  clickable link is the profile bio. Tag that, and say "link in bio" on screen.
- **One bio link covers every post**, so you get channel-level attribution, not
  per-post. Usually fine. If you really need per-post, swap the bio link per post.
- **Some apps strip query strings.** If a channel shows traffic but no tag, test
  by clicking your own link from that app before blaming the tracking.
- **Shorteners hide the tag** from readers but still pass it through — handy when
  a raw `?r=` looks spammy.

## What to check after posting

Wait for a real sample, then look at results per source — not visits, results.
Include spend, and sort by cost per result. The channel with the most traffic is
often not the one worth more money.

Also watch **engagement per source**, not just volume. One channel produced 5
results against another's 140, but those 5 went twice as deep into the product.
Volume alone would have pointed the budget at the wrong place.

## The rule

Never post a link you can't trace. If you're about to and there's no tag, stop
and add one. Ten seconds now, or permanent uncertainty later.
