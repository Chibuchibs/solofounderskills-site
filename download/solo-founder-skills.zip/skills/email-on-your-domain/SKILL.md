---
name: email-on-your-domain
description: Get a working address like support@yourdomain without paying for a mailbox, using free forwarding into an inbox you already read. Use this whenever someone needs a professional email address on their own domain, is about to publish a contact or support address, is being upsold a hosted mailbox by their registrar, or asks about MX records, SPF, DMARC or why their mail isn't arriving. Also use when replies sent from a domain address land in spam.
---

# A working address on your domain, for nothing

You need `support@yourdomain` or `hello@yourdomain`. Your registrar will offer
to sell you a mailbox for a monthly fee per address.

You almost certainly don't need one. What you need is **forwarding**: mail sent
to your domain is delivered to an inbox you already have. Free, and it takes
about ten minutes.

⚠️ **Publishing an address before it works is worse than having none.** A
bounced message from a customer who had a fixable problem becomes a refund
request, a dispute, or a bad review. Set it up before you print it anywhere.

## Mailbox versus forwarding

- **A mailbox** stores mail on the provider's servers. You log into it. This is
  what you're being sold, and it's what you need only if the address must hold
  mail of its own, independently of you.
- **Forwarding** accepts mail at your domain and passes it to an existing inbox.
  Nothing is stored, you read it where you already read mail, and it costs
  nothing.

For one person with one brand, forwarding is almost always right. Several free
services do it. Pick one that needs no nameserver change, so your website is
never at risk.

## The records

Three records at your DNS provider. Your forwarding service will give you the
exact values — these are the shapes:

| Type | Name | Value | Priority |
|---|---|---|---|
| MX | `@` | `mx1.provider.example` | 10 |
| MX | `@` | `mx2.provider.example` | 20 |
| TXT | `@` | `v=spf1 include:spf.provider.example ~all` | — |

The MX records say where mail for your domain should go. The TXT record is SPF,
which says who is allowed to send mail claiming to be from you.

📌 **Mail records and website records are independent.** Adding MX records does
not touch the A records or CNAME that serve your site. If a guide tells you to
move your nameservers for email, you are being asked to move your whole zone —
find a service that doesn't require it.

## Four ways this silently fails

**⚠️ The `~all` at the end of the SPF record.** A real case: the DNS form's
value box was narrow, the end of the string was scrolled out of view, and the
record was nearly saved as `v=spf1 include:...` with nothing after it. SPF
without a final `all` mechanism **saves without error and does nothing** — it
never tells receiving servers what to do with mail that fails the check.

Click into the field and jump to the end before saving. Then check the saved
value, not the one you typed.

**⚠️ `@` is not the same as your domain name.** The Name or Host field wants
`@`, meaning "the domain itself." Typing `yourdomain.com` there makes many
providers append the domain again, producing a record for
`yourdomain.com.yourdomain.com` that nothing will ever read. The record looks
present and does nothing.

**⚠️ Pre-existing MX records compete with yours.** Registrars often add their
own MX records pointing at a mailbox service you never set up. If those remain,
mail may be delivered to a mailbox you can't log into and vanish without a
bounce. Delete them before adding yours.

**⚠️ Minimum TTL.** Some providers reject values under a floor (600 seconds is
common). Typing `10`, meaning ten minutes, gets rejected with an unhelpful
error. Use the minimum they allow.

## Verify from outside, not from the dashboard

A saved record is not a delivered email. Two checks, in order:

```bash
dig +short MX yourdomain.com
dig +short TXT yourdomain.com
```

Both should return what you entered. Then **send a real email** to the new
address from a phone or another account and confirm it arrives. Check spam —
first delivery to a new destination sometimes lands there once.

Also re-check the website still loads. It should be untouched, but confirming
costs one request.

## ⚠️ The DMARC trap that bites later

Your domain may already carry a DMARC record — some registrars add one by
default. It looks like:

```
v=DMARC1; p=quarantine; ...
```

For *incoming* mail this is harmless and in fact protective: it tells receivers
to filter anything that forges your domain.

**But it governs mail claiming to be from you.** The day you set up your normal
mail client to "send as" your domain address, your replies go out through that
client's servers — which your SPF record does not authorise, because it
authorises only the forwarding service. They fail the check, and `p=quarantine`
tells the receiver to put them in spam.

The failure is silent. You see a sent message; the customer never does.

📌 If you enable send-as later, **add that sending service to your SPF record**
at the same time. Then send yourself a test at a different provider and confirm
it lands in the inbox, not spam.

## Catch-all or one address?

A catch-all forwards anything at your domain — `support@`, `hello@`, and every
typo. Nothing ever bounces, which is the main argument for it.

The cost is spam: senders blast common addresses at domains, and a catch-all
accepts all of it. For a new domain it's quiet; it grows.

Start with a catch-all so nothing is lost. If the junk becomes tiring, replace it
with the one or two specific addresses you actually publish.

## If the address will hold customer mail

Two things worth doing before it's in front of anyone:

- **Forward it into an inbox separate from your personal one** if you'll ever
  connect automation or an assistant to it. Anything with access to the
  destination can read everything that lands there.
- **Set the sending display name to your business**, not whatever your account
  defaulted to. That name appears on every reply a customer receives.

## Done when

- `dig` returns your MX and SPF records
- A real test email arrives
- The website still loads
- The SPF record ends in `~all`
- No leftover MX records from your registrar
- The address is published only after all of the above
