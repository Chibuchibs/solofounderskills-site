---
name: production-verification-loop
description: Prove a change actually works on the live site by driving the deployed page, rather than reporting success from local code. Use this after any deploy, whenever claiming a fix is live, when someone asks "is it working?", "did it deploy?" or reports that a change didn't appear, and whenever you're about to tell someone a feature works.
---

# Check the deployed thing, not your copy

Editing a file isn't shipping. Deploying isn't serving. The gap between them is
where false "it's fixed" claims come from.

## The loop

**1. Deploy, then wait for the new version to actually serve.**

```bash
i=0
until curl -s "https://example.com/?cb=$i" -o /tmp/live.html \
      && grep -q "unique-string-from-this-change" /tmp/live.html; do
  i=$((i+1)); [ $i -gt 18 ] && { echo TIMEOUT; break; }; sleep 8
done
```

Use a cache-busting query and a string that only exists in the new version.

**2. Check the served file, not the local one.** Grep what came back from the
URL. It's easy to confirm your own working copy by accident.

**3. Drive the page.** Open the deployed URL in a browser, do what a user would
do, and read the state back.

**4. Show evidence.** A screenshot, a state dump, a row count — something that
would be different if the change hadn't worked.

## Prove it, don't assert it

The strongest evidence is making the page demonstrate the behaviour.

For a timing-based interaction, have the page read its own rendered state and act
on it — sample the pixel where a target is drawn and trigger when it changes. If
an automated run that follows the on-screen instructions now scores well, the
feature works, and you can say so with a number instead of an opinion.

Some practical notes:

- **Aim for the middle of a target, not the first frame it's touched.** Pixel
  reads are a frame stale, so first-touch lands on the edge. One bot scored 2/5
  on edges and 5/5 aiming at the centre with no change to the code in between.
  Reporting the 2/5 would have been a false negative.
- **Don't run a long polling loop inside one script call.** It'll time out and
  leave the page mid-state. Split it into steps.
- **Clear local storage between runs** or you'll test a resumed session instead
  of a new one.

## Say what you actually verified

Distinguish clearly:

- "The file is being served" — a grep
- "The feature works" — you drove it and saw the result
- "I couldn't reproduce the bug" — not the same as "it's fixed"

If you couldn't reproduce a reported bug, say that plainly, say what you fixed
instead and why you think it's related, and ask for the specifics that would
narrow it — what they did immediately before, which device, which screen.

Claiming a fix you haven't demonstrated costs more trust than admitting you're
working from a hypothesis.
