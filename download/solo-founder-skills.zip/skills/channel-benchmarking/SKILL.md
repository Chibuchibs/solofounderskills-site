---
name: channel-benchmarking
description: Work out what a marketing channel actually costs per result, decide when a channel is dead, and tell the difference between a bad ad and a bad placement. Use this whenever someone is running or considering paid ads, sponsored posts, influencer deals or any paid traffic, when they're comparing channels, when they ask "is this working?", "should I keep spending?", "why no clicks?", or when they share ad dashboard numbers, impressions, CTR or spend figures.
---

# What does a result actually cost here?

Most paid-channel decisions get made on impressions, which measure almost
nothing. What you want is one number you can carry into every other
conversation: **cost per result**.

## Get the benchmark first

Work out, from real spend:

```
cost per click  = total spend / clicks
cost per signup = total spend / signups
```

Once you have it, every other offer becomes answerable. Somebody wants 50 for a
post? Then it has to deliver *price ÷ benchmark* results to be worth it. That's not a bluff and it's not a haggle — it's a question they can
answer.

Say it plainly to the seller: *"I currently pay about X per click. Tell me what
your post delivers and I'll tell you what it's worth."* It changes the
conversation from "what's your rate" to "what do you deliver", which is the one
you want.

## Separate the two failures

Two completely different problems get reported as "the ads aren't working":

**Nobody clicks.** That's reach or placement. The creative might be fine.

**People click and then leave.** That's the landing page, the offer or the price.

Work out the click-through rate and the click-to-result rate separately:

```
CTR            = clicks / impressions
click-to-result = results / clicks
```

A real case: a banner had a CTR of **0.0105%** — about a tenth of normal display
advertising — but **67%** of the people who clicked went on to sign up. The
landing page was fine. The placement couldn't deliver clicks. Redesigning the
banner a third time would have been wasted effort, and that's exactly what was
about to happen.

## Small numbers mean nothing — check before concluding

With tiny click counts, your instinct will lie to you. Before declaring a new
version better, check whether the difference is just noise.

Rough guide: with a few thousand impressions and a CTR near 0.01%, you expect
well under one click. Getting zero proves nothing. Getting two proves nothing.

Worked example: version 1 got **0 clicks in ~4,000 impressions**, version 2 got
**3 clicks in ~28,000**. That looks like an improvement. It isn't — both are what
a 0.01% rate predicts. The honest conclusion is "the redesign changed nothing
measurable, and the channel is weak".

If you want a number: for rare events, the chance of seeing zero when the true
rate is `p` over `n` impressions is roughly `e^(-n×p)`. If that's above about
0.2, zero clicks tells you nothing.

## Compare free against paid honestly

Put every channel in one table with spend included:

| Source | Results | Engagement | Spend | Cost each |
|---|---|---|---|---|
| Short video post | 5 | deep | 0 | free |
| Paid banner | 2 | moderate | 707 | 354 |
| Direct / unknown | 140 | shallow | — | — |

That table once reversed a plan. A **free** post had produced more results, at
better engagement, than everything the paid banner had bought. The right next
move wasn't to spend the remaining budget — it was to make two more free posts.

Rule of thumb: **don't pay for reach while a free channel is still unexhausted.**

## When to call it

A channel is dead when:

- CTR is an order of magnitude below normal for that format, **and**
- a creative change has already failed to move it, **and**
- the click-to-result rate shows the problem isn't downstream

At that point stop iterating on creative. Pause, keep the remaining budget, and
put it where something is already working.

Pausing also beats slow-burning a balance. You keep the money and you stop
generating data that will tempt you into another redesign.

## Before you spend again

- Is the link tagged so you'll be able to tell? (see `attribution-discipline`)
- Do you know what a result is worth to you? If the product earns nothing yet,
  say so out loud — you're buying learning, not revenue, and the budget should be
  sized like it.
- Is there a free version of this channel you haven't finished trying?
