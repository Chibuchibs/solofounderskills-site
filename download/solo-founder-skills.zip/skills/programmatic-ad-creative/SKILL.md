---
name: programmatic-ad-creative
description: Generate ad banners, social cards and promo images at exact platform dimensions from code, with no design tools and no heavy dependencies. Use this whenever someone needs a banner, ad creative, social preview card, Open Graph image, thumbnail or promo graphic at a specific size, mentions ad specs or dimensions, or has had an upload rejected for being the wrong format.
---

# Make the image in code

For ad slots and social cards you need exact pixel dimensions and a small file.
A script beats a design tool here: it's repeatable, it's versioned, and you can
regenerate the whole set when the message changes.

Pillow handles this fine and is usually already available.

## The approach

```python
from PIL import Image, ImageDraw, ImageFont
import os

W, H = 636, 212                       # exactly the slot's spec
img = Image.new('RGB', (W, H), '#f2e4c6')
d = ImageDraw.Draw(img)

# Font paths differ per OS — try a few and fail loudly rather than silently
# falling back to the default bitmap font, which looks broken at any size.
CANDIDATES = [
    '/System/Library/Fonts/Supplemental/Arial Bold.ttf',            # macOS
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',          # Linux
    'C:/Windows/Fonts/arialbd.ttf',                                  # Windows
]
path = next((p for p in CANDIDATES if os.path.exists(p)), None)
if not path:
    raise SystemExit('No font found — install one or point at a .ttf you have')
font = ImageFont.truetype(path, 34)

def centre(draw, text, font, cx, cy):
    """Centre text properly. textbbox returns (x0, y0, x1, y1) where y0 is the
    top bearing — the gap above the glyphs. Subtracting only (y1 - y0) and
    ignoring y0 leaves the text sitting low by that bearing: measured at 6px
    for 34pt Arial Bold, which is clearly visible on a 212px banner."""
    b = draw.textbbox((0, 0), text, font=font)
    w, h = b[2] - b[0], b[3] - b[1]
    draw.text((cx - w / 2 - b[0], cy - h / 2 - b[1]), text, font=font, fill='#ffffff')

centre(d, 'PLAY NOW', font, W / 2, H / 2)
img.save('banner.png', optimize=True)
print(os.path.getsize('banner.png'), 'bytes')
```

Key habits:

- **Measure text with `textbbox` and subtract the bearing**, as above. Centring
  on height alone is the common bug and it's visible at small sizes.
- **Don't let the font silently fall back.** Pillow's default is a bitmap font
  that looks broken; failing loudly is better than shipping that.
- **Build it as a function of the copy**, so a new message is a one-line change
  rather than a redraw.
- **Print the file size** and check it against the platform's limit before
  uploading.

## Writing for the size

At banner dimensions you have room for about four words that matter. Decide which
four before you open the editor.

- A visible **call to action** ("PLAY NOW", "TRY FREE") outperforms a clever line
- Say what it **is** in two or three words
- **Contrast beats decoration** — it'll be rendered small, on a busy page, often
  on a phone

## Upload gotchas

- **Some upload checks are case-sensitive on the extension.** A file named
  `.PNG` was rejected twice as "invalid" when the identical file as `.png` went
  through. If a valid file is rejected, rename to lowercase before debugging
  anything else.
- Check the **exact** dimensions required, not "about that size".
- Some platforms re-encode. If quality matters, upload the largest allowed.

## Don't mistake creative for placement

Worth knowing before you redesign a third version: if a banner gets very few
clicks, that's often the placement, not the artwork. Check the click-through
rate against what's normal for the format first. One banner was redesigned twice
before the numbers showed that both versions performed identically — around a
tenth of normal — and the channel itself was the problem.

Iterating on creative is satisfying and cheap. Make sure it's the actual
constraint before spending the afternoon on it.
