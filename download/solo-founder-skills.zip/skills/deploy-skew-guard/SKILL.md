---
name: deploy-skew-guard
description: Stop a fresh page loading stale JavaScript after a deploy, publish only the files you meant to, and get the order right when a change spans a database and a client. Use this whenever someone deploys a site or app, sees errors like "does not provide an export named" or behaviour that doesn't match the code, mentions caching, CDN, hard refresh, or is about to ship a change that touches both a server function and the client that calls it.
---

# Don't let a fresh page meet stale code

Two deploy problems cause a lot of confusing bugs, and both have cheap permanent
fixes.

## Problem 1: mixed versions

Static hosts cache aggressively, and often ignore the cache headers you set. So a
browser can load a **new** `index.html` that imports an **old** `app.js`. You get
errors like:

```
SyntaxError: The requested module './game.js' does not provide an export named 'newThing'
```

The page isn't broken. It's two deploys at once.

**Fix: stamp a version on every import at build time.**

```bash
VERSION=$(date +%Y%m%d%H%M%S)
cp index.html app.js net.js config.js dist/
sed -i '' "s|from '\./app\.js'|from './app.js?v=$VERSION'|g" dist/index.html
sed -i '' "s|from '\./net\.js'|from './net.js?v=$VERSION'|g" dist/index.html
```

Now a stale HTML file can only load modules matching it. Mixed versions become
impossible rather than unlikely.

Watch for: when you add a new module, **add it to the stamping list too**. An
unstamped import is the one that'll bite you later.

## Problem 2: publishing more than you meant to

If the publish directory is your working folder, everything in it goes public —
including things you'd never choose to publish.

One site served its database migration files at a guessable URL, exposing a
blocked-word list and the exact link-detection patterns used for spam filtering.
Anyone reading them could design around them.

**Fix: build an allowlist, publish that.**

```bash
rm -rf dist; mkdir -p dist
cp index.html app.js net.js config.js share.png dist/     # named explicitly
```

If a file isn't named, it can't ship. Specs, SQL, notes and keys stay local by
default rather than by remembering.

## Problem 3: getting the order wrong

When a change spans a database function and the client that calls it, order
matters:

**Server first, client second.**

Deploy the client first and it calls a function that doesn't exist yet — every
user in that window gets an error. Deploy the server first and nothing calls the
new function yet, which is harmless.

Same logic for removing things: client first, then server, so nothing is calling
what you're about to delete.

When writing a server function that a rollout will reach gradually, give new
parameters defaults so browsers running the old client keep working.

## Verify on the deployed URL

Deploying isn't shipping. Poll until the new version is actually being served:

```bash
i=0
until curl -s "https://example.com/?cb=$i" -o /tmp/live.html \
      && grep -q "$VERSION" /tmp/live.html; do
  i=$((i+1)); [ $i -gt 18 ] && { echo TIMEOUT; break; }; sleep 8
done
```

Then check the thing you actually changed is present in what's being served — not
in your local file.

## One more trap

Writing the fetched page into a shell variable and grepping it can break on
emoji or unusual characters in some shells. Write to a file and grep the file.
