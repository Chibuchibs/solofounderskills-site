---
name: isolate-the-layer
description: Design one diagnostic that tests every layer of a problem at once, instead of guessing and redeploying. Use this whenever a bug only happens on someone else's device, only in production, or only sometimes — and whenever each test costs a round trip through another person, a deploy, a slow build or a device you don't have. Also use when a bug has already survived two or more attempted fixes.
---

# Build one test that answers everything

When each attempt costs a deploy and a message to someone else, guessing is
expensive. A grid that isolates every layer at once turns six round trips into
one.

## When it's worth it

- The bug only shows on a device you don't have
- Each test needs another person to try it and report back
- Two or more fixes have already failed
- You can't reproduce it yourself

## How to design the grid

List the layers that could be at fault, and the simplest possible version of the
thing. Then cross them.

Real example — audio that played as static on one phone but worked everywhere
else. Two candidate layers (how the sound was generated, how it was played) and
two content types (a plain beep, the real audio):

| | Plain beep | Real audio |
|---|---|---|
| Method A | test A | — |
| Method A + a flag | test B | test D |
| Method B (file) | test C | test E |

Five buttons on one page. The person taps each, marks **clean / distorted /
silent**, and sends back the grid.

Every outcome points somewhere specific:

- Beep clean on A, distorted on C → the playback method is at fault
- Beep clean everywhere, real audio distorted → the content is at fault
- Everything silent → neither; it's a permissions or routing problem

In that case the answer was: plain method **silent**, same method with one flag
set **clean**. One line of configuration, found in a single test, after two
earlier fixes had failed over several days.

## Make reporting back easy

The person testing isn't going to write a careful report. Give them:

- Big obvious buttons, one per test
- Three verdict options, not a text box
- An auto-filled summary including device and browser details
- A copy button

And expect the copy button to fail. Clipboard APIs are unreliable on mobile — if
you get back something unrelated, they probably pasted a stale clipboard. Have a
fallback: "just read the five answers off the screen and type them."

## The trap: shared state between tests

**Tests on one page can contaminate each other.** In the audio example, once any
test set the playback flag, it stayed set for the whole page — so later tests
inherited it and looked like they passed on their own merits. One result was
completely misleading because of this.

So: say explicitly which tests are order-dependent, reload between them if it
matters, or make each test reset the state it touches. And when you read the
results, ask whether a passing test could have borrowed its pass from an earlier
one.

## Check who actually ran it

Confirm the test ran where you think. One set of results came back clean on
everything — the user agent showed a desktop browser, not the phone. It proved
the harness worked and nothing about the bug.

Always include the user agent in the output, and read it before drawing
conclusions.

## Afterwards

Keep the diagnostic page but take it out of the published build. It's a tool,
not part of the product. Leave a note with it explaining the contamination trap,
because the next person to use it — including you, in six months — will hit it.
