# Ship & Sell — a Claude skill pack

Sixteen skills for building a product on your own and getting people to use it.

These aren't summaries of blog posts. Each one came out of a real bug, a real
wasted budget or a real decision that went wrong, and encodes what it cost to
find out. Where there's a number in here, it was measured.

## What's in it

### Deciding what to build
| Skill | What it does |
|---|---|
| `idea-kill-search` | Kills an idea in an hour with three searches and four checks |

### Shipping
| Skill | What it does |
|---|---|
| `seo-foundation-audit` | Canonical host, robots, sitemap, social cards, structured data |
| `static-host-migration` | Move hosts without breaking your email |
| `deploy-skew-guard` | Stop fresh pages loading stale code; publish only what you meant to |
| `client-identity-without-auth` | Shared/multiplayer apps with no signup wall, still safe |
| `programmatic-ad-creative` | Banners and social cards at exact specs, from code |

### Checking it actually works
| Skill | What it does |
|---|---|
| `simulate-the-instructions` | Test whether doing what the screen says actually wins |
| `target-legibility-audit` | Find the things on screen people can't see |
| `production-verification-loop` | Prove a fix on the live site, not in your editor |
| `isolate-the-layer` | One diagnostic that tests every layer at once |
| `randomness-correctness` | Catch shuffles and odds that aren't fair |

### Getting people to use it
| Skill | What it does |
|---|---|
| `channel-benchmarking` | What a result really costs, and when a channel is dead |
| `attribution-discipline` | Tag before you post; what "direct" is hiding |
| `community-admin-negotiation` | What a group is worth, and how to buy a post |
| `store-listing-conversion` | The two screenshots and the subtitle that do the work |
| `cohort-retention-analysis` | Did the change work? Averages won't tell you |

## A few things these will tell you that you might not expect

- An instruction that's backwards makes a game unplayable, and no amount of
  difficulty tuning fixes it. There's a test for this.
- `array.sort(() => Math.random() - 0.5)` is not a shuffle. Measured bias
  included.
- A big "direct" traffic number is a measurement failure, not a mystery.
- Member count is the worst way to value a community group. There's a better one.
- Changing web hosts is mostly a mail-safety problem.

## Install

See `INSTALL.md`. Short version: these are plain Markdown files. Drop them in a
folder Claude reads, or paste one into a project's instructions.

## Make them yours

Don't use these as-is forever. The real value comes when you add your own
context — your stack, your market, your numbers. Open any skill, add what you
know, and it gets better at your work specifically.

When Claude gets something wrong while using one, tell it to update the skill.
That's the loop.

## Licence

Yours to use and adapt in your own work. Please don't resell the pack itself.
